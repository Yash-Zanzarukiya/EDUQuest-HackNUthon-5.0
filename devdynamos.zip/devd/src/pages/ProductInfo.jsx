import { useEffect, useState, useSelector } from "react";
import { getCertificates } from "../backend/contract";

export default function ProductInfo() {
  const [product, setProduct] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const userdata = useSelector((state) => state.auth.userData);

  useEffect(() => {
    const getProductInfo = async () => {
      await getCertificates(userdata?._id).then((data) => {
        if (data[0]) {
          setProduct(res.data);
          setIsLoading(false);
        } else setIsLoading(false);
      });
    };
    getProductInfo();
  }, [slug]);

  if (isLoading)
    return <div className=" w-full h-screen text-center text-4xl">Getting data...</div>;

  return (
    product && (
      <div className="w-ful flex align-middle justify-center">
        <div className=" text-center text-3xl w-1/2 flex align-middle justify-center flex-col gap-5">
          <div className=" mt-36 flex align-middle justify-center flex-col gap-3">
            <span>
              Person Name:
              <span className=" font-bold"> {product && product[0]?.name}</span>
            </span>
            <span>
              University:
              <span className=" font-bold"> {product && product[0]?.uni}</span>
            </span>
            <span>
              Grad Year:
              <span className=" font-bold"> {product && product[0]?.gradYear}</span>
            </span>
          </div>
          <div>
            <h1 className=" text-4xl">
              <span className=" text-green-500">Genuine Product</span>
            </h1>
          </div>
        </div>
      </div>
    )
  );
}
