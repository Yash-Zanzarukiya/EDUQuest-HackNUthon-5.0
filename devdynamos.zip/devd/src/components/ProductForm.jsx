import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { Button } from "./index";
import { useNavigate } from "react-router-dom";
import { registerCertificates } from "../backend/contract";
import { useSelector, useDispatch } from "react-redux";
import authService from "../backend/auth";
import { login, logout } from "../app/authSlice";

export default function ProductForm({ product }) {
  const { register, handleSubmit, watch, setValue, control, getValues } = useForm({
    defaultValues: {
      product_name: product?.product_name || "",
      MRP: product?.MRP || "",
      product_id: product?.product_id || "",
    },
  });

  const dispatch = useDispatch();

  useEffect(() => {
    authService
      .getCurrentUser()
      .then((blob) => blob.json())
      .then((userData) => {
        if (userData) {
          dispatch(login(userData.data));
        } else {
          dispatch(logout());
        }
      });
  }, []);

  const userdata = useSelector((state) => state.auth.userData);

  const navigate = useNavigate();

  const submit = async () => {
    await registerCertificates(
      userdata?.fullName,
      userdata?.university,
      userdata?._id,
      userdata?.gradYear
    ).then((res) => {
      navigate(`/certificate-detail`);
    });
  };

  return (
    <div className="flex items-center justify-center w-full">
      <div className={`mx-auto w-2/5 bg-gray-100 rounded-xl p-8 border border-black/10`}>
        <h2 className="text-center text-3xl font-bold leading-tight mb-2">Generate Certificate</h2>
        <form
          onSubmit={handleSubmit(submit)}
          enctype="multipart/form-data"
          className="flex items-center justify-center flex-wrap"
        >
          <Button type="submit" className="w-1/3">
            Generate Certificate
          </Button>
        </form>
      </div>
    </div>
  );
}
