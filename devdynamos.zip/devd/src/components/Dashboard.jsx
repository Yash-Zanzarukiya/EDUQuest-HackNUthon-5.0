import { useEffect, useState } from "react";
import backendService from "../backend/auth";
import { useLocation } from "react-router-dom";
import { ethers } from "ethers";

export default function Dashboard() {
  let location = useLocation();
  const [user, setUser] = useState({});

  useEffect(() => {
    const getUser = async () => {
      await backendService
        .getCurrentUser()
        .then((blob) => blob.json())
        .then((res) => {
          let userData = res.data;
          setUser(userData);
        });
    };
    getUser();
  }, [location.pathname]);

  return (
    <div className="w-full py-8 ">
      <div className=" min-h-full flex flex-wrap items-center justify-center">
        <div className="w-full flex align-middle justify-center">
          <div className=" text-center text-3xl w-1/2 flex align-middle justify-center flex-col gap-5">
            <div className=" mt-36 flex align-middle justify-center flex-col gap-3">
              <span className="flex align-middle justify-center">
                <img className=" font-bold h-36 rounded" src={user && user.avatar} />
              </span>
              <span>
                Full Name:
                <span className=" font-bold"> {user && user?.fullName}</span>
              </span>
              <span>
                username:
                <span className=" font-bold"> {user && user?.username}</span>
              </span>
              <span>
                email: <span className=" font-bold">{user && user?.email}</span>
              </span>
              <span>
                university:
                <span className=" font-bold"> {user && user?.university}</span>
              </span>
              <span>
                gradYear:
                <span className=" font-bold ml-1">{user && user?.gradYear}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
